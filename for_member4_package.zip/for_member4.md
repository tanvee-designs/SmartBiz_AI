# Member 4-এর জন্য: Welcome Email (Day 3) জোড়া লাগানোর নির্দেশনা

আমি (Member 3) AI দিয়ে Welcome Email বানানোর অংশ তৈরি করেছি।
Input: `name`, `email`, `company`, `phone`
Output: `subject`, `body`, `html`, `source` (ai / fallback)

## ধাপ ১: ফাইল কপি করো
এই দুটো ফাইল তোমার ব্যাকএন্ড ফোল্ডারে (যেখানে `main.py` আছে) রাখো:
- `generate_email.py`
- `prompt_template.txt`

## ধাপ ২: requirements.txt-এ যোগ করো
```
google-genai
python-dotenv
```
তারপর: `pip install -r requirements.txt`

## ধাপ ৩: .env-এ যোগ করো
```
GEMINI_API_KEY=
AI_MODEL=gemini-3.5-flash
COMPANY_NAME=SmartBiz AI
COMPANY_SERVICES=AI-powered lead automation for businesses
SENDER_NAME=SmartBiz AI Team
COMPANY_CTA=এই ইমেইলে রিপ্লাই করুন
EMAIL_LANGUAGE=Bangla
```
`GEMINI_API_KEY` ফাঁকা থাকলেও কাজ করবে (তখন ডিফল্ট fallback email যাবে)।

## ধাপ ৪: models.py-তে EmailLog যোগ করো
উপরের import লাইনে `ForeignKey` যোগ করো:
```python
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
```
তারপর ফাইলের শেষে:
```python
class EmailLog(Base):
    __tablename__ = "email_logs"

    id = Column(Integer, primary_key=True, index=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=False, index=True)
    to_email = Column(String(150), nullable=False)
    subject = Column(String(255), nullable=False)
    body = Column(Text, nullable=False)
    generated_by = Column(String(20), default="ai")   # "ai" অথবা "fallback"
    status = Column(String(20), default="pending")    # pending / sent / failed
    created_at = Column(DateTime, default=datetime.utcnow)
```
টেবিল `create_all` দিয়ে নিজে থেকে তৈরি হবে।

## ধাপ ৫: main.py-তে যোগ করো (তোমার বর্তমান main.py যেমন আছে থাকবে)

**সাবধান:** তোমার `main.py` (create_lead, CORS, n8n_client সহ) replace করবে না, শুধু নিচের দুটো অংশ যোগ করো।

**(ক) উপরের import-এর সাথে এই লাইনটা যোগ করো:**
```python
from generate_email import generate_welcome_email
```

**(খ) ফাইলের একদম শেষে (create_lead-এর নিচে) এই তিনটা endpoint যোগ করো:**
```python
# ---- Day 3: Welcome Email Automation ----

@app.post("/automation/welcome-email/{lead_id}")
def create_welcome_email(lead_id: int, db: Session = Depends(get_db)):
    lead = db.query(models.Lead).filter(models.Lead.id == lead_id).first()
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")

    result = generate_welcome_email({
        "name": lead.name,
        "email": lead.email,
        "company": lead.company,
        "phone": lead.phone,
    })

    log = models.EmailLog(
        lead_id=lead.id,
        to_email=lead.email,
        subject=result["subject"],
        body=result["body"],
        generated_by=result["source"],
    )
    db.add(log)
    db.commit()
    db.refresh(log)
    return {"log_id": log.id, "to": lead.email, **result}


@app.patch("/email-logs/{log_id}/status")
def update_email_status(log_id: int, status: str, db: Session = Depends(get_db)):
    log = db.query(models.EmailLog).filter(models.EmailLog.id == log_id).first()
    if not log:
        raise HTTPException(status_code=404, detail="Log not found")
    log.status = status
    if status == "sent":
        lead = db.query(models.Lead).filter(models.Lead.id == log.lead_id).first()
        if lead:
            lead.status = "email_sent"
    db.commit()
    return {"log_id": log.id, "status": log.status}


@app.get("/email-logs")
def list_email_logs(db: Session = Depends(get_db)):
    return db.query(models.EmailLog).order_by(models.EmailLog.created_at.desc()).all()
```
(তোমার main.py-তে `import models`, `Depends`, `HTTPException`, `Session`, `get_db` আগে থেকেই আছে।)

**(গ) জরুরি:** n8n-এ যে Lead যায় (`lead_data`), তাতে `id` ফিল্ড থাকতে হবে (`schemas.LeadResponse`-এ `id` আছে কিনা দেখো)। না থাকলে `id: int` যোগ করো, নইলে n8n কোন Lead-এর email বানাবে জানবে না।

## ধাপ ৬: টেস্ট করো
1. সার্ভার চালু: `python -m uvicorn main:app --reload`
2. `http://localhost:8000/docs` খুলে একটা Lead বানাও
3. `POST /automation/welcome-email/1` চালাও, `subject`, `body`, `html`, `source` আসা উচিত
4. `GET /email-logs` এ লগ দেখো

## n8n (Member 2)-এর জন্য: পুরো flow
1. Backend `POST /api/leads` -> n8n Webhook-এ Lead যায় (আগে থেকেই আছে, `id` সহ)
2. n8n HTTP Request: `POST http://<backend>/automation/welcome-email/{{ $json.body.id }}`
3. n8n Gmail node:
   - To: `{{ $json.to }}`
   - Subject: `{{ $json.subject }}`
   - Message: `{{ $json.html }}`
4. Gmail-এর পর n8n HTTP Request: `PATCH http://<backend>/email-logs/{{ $('HTTP Request').item.json.log_id }}/status?status=sent`
(ব্যর্থ হলে `status=failed` দিয়ে একই কল)
নোট: n8n ও backend এক কম্পিউটারে না চললে backend-এর URL n8n থেকে ধরা পড়তে হবে (ngrok বা deploy)। n8n Docker-এ চললে `localhost`-এর বদলে `host.docker.internal` লাগতে পারে।

## Dashboard (Member 5)-এর জন্য
`GET /email-logs` থেকে status, subject, to_email, generated_by, created_at পাওয়া যাবে।
